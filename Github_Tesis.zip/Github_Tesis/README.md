﻿# Ejemplos de audio por SNR`n`nTres ejemplos de la última versión del modelo: audio sucio, audio procesado y audio limpio.
