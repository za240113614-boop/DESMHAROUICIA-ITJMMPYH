﻿# SNR 10 dB`n`nAudio sucio, procesado y limpio.
