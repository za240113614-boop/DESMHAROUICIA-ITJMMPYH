﻿# SNR -5 dB`n`nAudio sucio, procesado y limpio.
