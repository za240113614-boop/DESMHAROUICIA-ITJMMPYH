﻿# SNR 0 dB`n`nAudio sucio, procesado y limpio.
